# ميعاد - Meaad

نظام حجز المواعيد الذكي للصالونات مع إيجنت AI يتصل ويحجز تلقائياً.

## التشغيل

```bash
npm install
npm run dev
```

افتح [http://localhost:3000](http://localhost:3000) في المتصفح.
