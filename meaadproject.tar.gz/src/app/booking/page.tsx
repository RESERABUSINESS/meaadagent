"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Calendar,
  Clock,
  Scissors,
  User,
  Phone,
  Bot,
  Send,
  ArrowRight,
  CheckCircle,
  Sparkles,
  MapPin,
} from "lucide-react";

const services = [
  { id: "haircut", name: "قص شعر", price: 50, duration: "30 دقيقة", icon: "✂️" },
  { id: "beard", name: "تهذيب لحية", price: 30, duration: "20 دقيقة", icon: "🧔" },
  { id: "facial", name: "عناية بالوجه", price: 80, duration: "45 دقيقة", icon: "✨" },
  { id: "hair-color", name: "صبغة شعر", price: 150, duration: "60 دقيقة", icon: "🎨" },
  { id: "hair-treatment", name: "علاج شعر", price: 120, duration: "45 دقيقة", icon: "💆" },
  { id: "full-package", name: "باكج كامل", price: 200, duration: "90 دقيقة", icon: "👑" },
];

const salons = [
  { id: "elegance", name: "صالون الأناقة", rating: 4.8, location: "الرياض - حي الملقا" },
  { id: "prestige", name: "صالون بريستيج", rating: 4.9, location: "الرياض - حي النرجس" },
  { id: "royal", name: "صالون رويال", rating: 4.7, location: "الرياض - حي الياسمين" },
  { id: "modern", name: "صالون المودرن", rating: 4.6, location: "جدة - حي الروضة" },
];

const timeSlots = [
  "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
  "12:00", "14:00", "14:30", "15:00", "15:30", "16:00",
  "16:30", "17:00", "17:30", "18:00", "18:30", "19:00",
];

type ChatMessage = {
  role: "agent" | "user";
  content: string;
};

export default function BookingPage() {
  const [mode, setMode] = useState<"manual" | "agent">("agent");
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState("");
  const [selectedSalon, setSelectedSalon] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [booked, setBooked] = useState(false);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      role: "agent",
      content:
        "مرحباً! أنا إيجنت ميعاد الذكي 🤖\nكيف أقدر أساعدك اليوم؟ قول لي وش تبي تحجز وأنا أرتب لك كل شي!",
    },
  ]);
  const [chatInput, setChatInput] = useState("");
  const [agentTyping, setAgentTyping] = useState(false);

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    const userMsg = chatInput.trim();
    setChatMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setChatInput("");
    setAgentTyping(true);

    setTimeout(() => {
      let agentReply = "";
      const lower = userMsg.toLowerCase();

      if (lower.includes("قص") || lower.includes("حلاق") || lower.includes("شعر")) {
        agentReply =
          "تمام! تبي قص شعر 💇‍♂️\nعندي مواعيد متاحة في صالون الأناقة وصالون بريستيج.\n\nيوم السبت الساعة 4:00 عصراً عند صالون الأناقة — تبي أأكد لك؟";
      } else if (lower.includes("أكد") || lower.includes("اي") || lower.includes("تمام") || lower.includes("نعم")) {
        agentReply =
          "تم تأكيد حجزك بنجاح! ✅\n\n📅 السبت\n⏰ 4:00 عصراً\n📍 صالون الأناقة - حي الملقا\n✂️ قص شعر\n\nبرسل لك تذكير قبل الموعد. يومك سعيد! 😊";
      } else if (lower.includes("صالون") || lower.includes("وين")) {
        agentReply =
          "عندنا صالونات ممتازة:\n\n⭐ صالون الأناقة (4.8) - حي الملقا\n⭐ صالون بريستيج (4.9) - حي النرجس\n⭐ صالون رويال (4.7) - حي الياسمين\n\nأي واحد تفضل؟";
      } else if (lower.includes("سعر") || lower.includes("كم")) {
        agentReply =
          "أسعارنا:\n\n✂️ قص شعر: 50 ر.س\n🧔 تهذيب لحية: 30 ر.س\n✨ عناية بالوجه: 80 ر.س\n🎨 صبغة شعر: 150 ر.س\n💆 علاج شعر: 120 ر.س\n👑 باكج كامل: 200 ر.س\n\nوش تبي تحجز؟";
      } else if (lower.includes("الغ") || lower.includes("عدل")) {
        agentReply =
          "تبي تلغي أو تعدل حجز؟ لا مشكلة!\nأعطني رقم الحجز أو اسمك وأنا أساعدك 👍";
      } else {
        agentReply =
          "فهمت! خلني أبحث لك عن أفضل موعد متاح...\n\nتقدر تقول لي:\n• وش الخدمة اللي تبيها\n• أي صالون تفضل\n• الوقت اللي يناسبك\n\nوأنا أرتب لك كل شي! 🎯";
      }

      setChatMessages((prev) => [...prev, { role: "agent", content: agentReply }]);
      setAgentTyping(false);
    }, 1500);
  };

  const handleBooking = () => {
    setBooked(true);
  };

  const service = services.find((s) => s.id === selectedService);
  const salon = salons.find((s) => s.id === selectedSalon);

  if (booked) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center p-4">
        <div className="glass-card rounded-3xl p-12 text-center max-w-md animate-slide-up">
          <div className="w-20 h-20 mx-auto rounded-full bg-accent/10 flex items-center justify-center mb-6">
            <CheckCircle className="w-10 h-10 text-accent" />
          </div>
          <h1 className="text-3xl font-bold mb-2">تم الحجز بنجاح!</h1>
          <p className="text-dark/60 mb-6">رقم الحجز: #MW-{Math.floor(Math.random() * 9000 + 1000)}</p>
          <div className="bg-primary/5 rounded-2xl p-4 text-right space-y-2 mb-6">
            <p className="flex items-center gap-2">
              <Scissors className="w-4 h-4 text-primary" />
              <span className="font-medium">{service?.name}</span>
            </p>
            <p className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              <span>{salon?.name} — {salon?.location}</span>
            </p>
            <p className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" />
              <span>{selectedDate}</span>
            </p>
            <p className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              <span>{selectedTime}</span>
            </p>
          </div>
          <div className="flex gap-3">
            <Link
              href="/"
              className="flex-1 bg-primary text-white py-3 rounded-xl font-bold hover:bg-primary-dark transition"
            >
              الرئيسية
            </Link>
            <Link
              href="/dashboard"
              className="flex-1 border-2 border-primary text-primary py-3 rounded-xl font-bold hover:bg-primary/5 transition"
            >
              مواعيدي
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link href="/" className="flex items-center gap-2 text-dark/60 hover:text-primary transition">
            <ArrowRight className="w-5 h-5" />
            الرجوع للرئيسية
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">ميعاد</span>
          </div>
        </div>

        <div className="flex gap-3 mb-8 justify-center">
          <button
            onClick={() => setMode("agent")}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              mode === "agent"
                ? "bg-primary text-white shadow-lg shadow-primary/30"
                : "glass-card text-dark/60 hover:text-primary"
            }`}
          >
            <Bot className="w-5 h-5" />
            حجز عبر الإيجنت
          </button>
          <button
            onClick={() => setMode("manual")}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              mode === "manual"
                ? "bg-primary text-white shadow-lg shadow-primary/30"
                : "glass-card text-dark/60 hover:text-primary"
            }`}
          >
            <Calendar className="w-5 h-5" />
            حجز يدوي
          </button>
        </div>

        {mode === "agent" ? (
          <div className="max-w-2xl mx-auto glass-card rounded-3xl overflow-hidden shadow-xl">
            <div className="bg-gradient-to-l from-primary to-primary-dark p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold">إيجنت ميعاد</h3>
                <p className="text-white/70 text-xs flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                  متصل — جاهز لمساعدتك
                </p>
              </div>
            </div>

            <div className="h-[500px] overflow-y-auto p-4 space-y-4">
              {chatMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-start" : "justify-end"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl p-4 text-sm whitespace-pre-line ${
                      msg.role === "agent"
                        ? "bg-primary/10 rounded-tr-md"
                        : "bg-secondary/10 rounded-tl-md"
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              {agentTyping && (
                <div className="flex justify-end">
                  <div className="bg-primary/10 rounded-2xl rounded-tr-md p-4 text-sm">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce" />
                      <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                      <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="border-t border-dark/5 p-4 flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                placeholder="اكتب رسالتك هنا..."
                className="flex-1 px-4 py-3 rounded-xl border border-dark/10 bg-white/50 focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
              <button
                onClick={handleSendMessage}
                className="bg-primary text-white p-3 rounded-xl hover:bg-primary-dark transition"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center justify-center gap-2 mb-8">
              {[1, 2, 3, 4].map((s) => (
                <div key={s} className="flex items-center gap-2">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${
                      step >= s
                        ? "bg-primary text-white"
                        : "bg-dark/10 text-dark/40"
                    }`}
                  >
                    {s}
                  </div>
                  {s < 4 && (
                    <div
                      className={`w-12 h-1 rounded ${
                        step > s ? "bg-primary" : "bg-dark/10"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>

            {step === 1 && (
              <div className="animate-slide-up">
                <h2 className="text-2xl font-bold mb-6 text-center">اختر الخدمة</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  {services.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => {
                        setSelectedService(s.id);
                        setStep(2);
                      }}
                      className={`glass-card rounded-2xl p-5 text-right hover:shadow-lg transition-all hover:-translate-y-1 ${
                        selectedService === s.id ? "ring-2 ring-primary" : ""
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-2xl">{s.icon}</span>
                        <span className="text-primary font-bold">{s.price} ر.س</span>
                      </div>
                      <h3 className="font-bold text-lg">{s.name}</h3>
                      <p className="text-dark/50 text-sm flex items-center gap-1 mt-1">
                        <Clock className="w-3 h-3" />
                        {s.duration}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="animate-slide-up">
                <h2 className="text-2xl font-bold mb-6 text-center">اختر الصالون</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  {salons.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => {
                        setSelectedSalon(s.id);
                        setStep(3);
                      }}
                      className="glass-card rounded-2xl p-5 text-right hover:shadow-lg transition-all hover:-translate-y-1"
                    >
                      <h3 className="font-bold text-lg mb-1">{s.name}</h3>
                      <p className="text-dark/50 text-sm flex items-center gap-1 mb-2">
                        <MapPin className="w-3 h-3" />
                        {s.location}
                      </p>
                      <div className="flex items-center gap-1 text-secondary">
                        <span className="text-sm font-bold">⭐ {s.rating}</span>
                      </div>
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setStep(1)}
                  className="mt-4 text-dark/50 hover:text-primary transition text-sm"
                >
                  ← رجوع
                </button>
              </div>
            )}

            {step === 3 && (
              <div className="animate-slide-up">
                <h2 className="text-2xl font-bold mb-6 text-center">اختر الموعد</h2>
                <div className="glass-card rounded-2xl p-6 mb-4">
                  <label className="block text-sm font-medium mb-2">التاريخ</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                    className="w-full px-4 py-3 rounded-xl border border-dark/10 bg-white/50 focus:outline-none focus:ring-2 focus:ring-primary/30 mb-4"
                  />
                  <label className="block text-sm font-medium mb-2">الوقت</label>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {timeSlots.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`py-2 rounded-lg text-sm font-medium transition ${
                          selectedTime === time
                            ? "bg-primary text-white"
                            : "bg-dark/5 hover:bg-primary/10 text-dark/70"
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => setStep(2)}
                    className="text-dark/50 hover:text-primary transition text-sm"
                  >
                    ← رجوع
                  </button>
                  <button
                    onClick={() => selectedDate && selectedTime && setStep(4)}
                    disabled={!selectedDate || !selectedTime}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-bold hover:bg-primary-dark transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    التالي
                  </button>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="animate-slide-up">
                <h2 className="text-2xl font-bold mb-6 text-center">بياناتك</h2>
                <div className="glass-card rounded-2xl p-6 space-y-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      <User className="w-4 h-4 inline ml-1" />
                      الاسم
                    </label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-dark/10 bg-white/50 focus:outline-none focus:ring-2 focus:ring-primary/30"
                      placeholder="اسمك الكريم"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      <Phone className="w-4 h-4 inline ml-1" />
                      رقم الجوال
                    </label>
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-dark/10 bg-white/50 focus:outline-none focus:ring-2 focus:ring-primary/30"
                      placeholder="05XXXXXXXX"
                      required
                    />
                  </div>

                  <div className="bg-primary/5 rounded-2xl p-4 space-y-2">
                    <h3 className="font-bold flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-primary" />
                      ملخص الحجز
                    </h3>
                    <p className="text-sm text-dark/60">
                      {service?.icon} {service?.name} — {service?.price} ر.س
                    </p>
                    <p className="text-sm text-dark/60">📍 {salon?.name}</p>
                    <p className="text-sm text-dark/60">📅 {selectedDate}</p>
                    <p className="text-sm text-dark/60">⏰ {selectedTime}</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => setStep(3)}
                    className="text-dark/50 hover:text-primary transition text-sm"
                  >
                    ← رجوع
                  </button>
                  <button
                    onClick={handleBooking}
                    disabled={!customerName || !customerPhone}
                    className="flex-1 bg-primary text-white py-3 rounded-xl font-bold hover:bg-primary-dark transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-5 h-5" />
                    تأكيد الحجز
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
