"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Calendar,
  Clock,
  MapPin,
  Scissors,
  Plus,
  BarChart3,
  Users,
  TrendingUp,
  Phone,
  Bot,
  CheckCircle,
  XCircle,
  AlertCircle,
} from "lucide-react";

type Booking = {
  id: string;
  service: string;
  salon: string;
  date: string;
  time: string;
  status: "confirmed" | "pending" | "cancelled";
  price: number;
};

const mockBookings: Booking[] = [
  {
    id: "MW-1234",
    service: "قص شعر",
    salon: "صالون الأناقة",
    date: "2026-07-01",
    time: "16:00",
    status: "confirmed",
    price: 50,
  },
  {
    id: "MW-1235",
    service: "تهذيب لحية",
    salon: "صالون بريستيج",
    date: "2026-07-03",
    time: "14:30",
    status: "pending",
    price: 30,
  },
  {
    id: "MW-1236",
    service: "عناية بالوجه",
    salon: "صالون رويال",
    date: "2026-06-25",
    time: "11:00",
    status: "confirmed",
    price: 80,
  },
  {
    id: "MW-1237",
    service: "باكج كامل",
    salon: "صالون الأناقة",
    date: "2026-06-20",
    time: "10:00",
    status: "cancelled",
    price: 200,
  },
];

const stats = [
  { label: "إجمالي الحجوزات", value: "24", icon: Calendar, color: "from-primary to-primary-light" },
  { label: "حجوزات هذا الشهر", value: "6", icon: TrendingUp, color: "from-accent to-emerald-400" },
  { label: "الصالونات المفضلة", value: "3", icon: MapPin, color: "from-secondary to-amber-400" },
  { label: "حجوزات بالإيجنت", value: "18", icon: Bot, color: "from-blue-500 to-blue-400" },
];

const statusConfig = {
  confirmed: { label: "مؤكد", icon: CheckCircle, color: "text-accent bg-accent/10" },
  pending: { label: "قيد الانتظار", icon: AlertCircle, color: "text-secondary bg-secondary/10" },
  cancelled: { label: "ملغي", icon: XCircle, color: "text-red-500 bg-red-50" },
};

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState<"upcoming" | "past">("upcoming");

  const upcoming = mockBookings.filter(
    (b) => b.status !== "cancelled" && new Date(b.date) >= new Date()
  );
  const past = mockBookings.filter(
    (b) => b.status === "cancelled" || new Date(b.date) < new Date()
  );

  const displayBookings = activeTab === "upcoming" ? upcoming : past;

  return (
    <div className="min-h-screen bg-surface">
      <div className="glass-card border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">ميعاد</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link
              href="/booking"
              className="bg-primary text-white px-5 py-2 rounded-xl font-medium hover:bg-primary-dark transition flex items-center gap-2 text-sm"
            >
              <Plus className="w-4 h-4" />
              حجز جديد
            </Link>
            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-1">مرحباً! 👋</h1>
          <p className="text-dark/60">هذي لوحة تحكم مواعيدك — كل شي منظم وجاهز.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, i) => (
            <div key={i} className="glass-card rounded-2xl p-5">
              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}
                >
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
              </div>
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-dark/50 text-sm">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="flex border-b border-dark/5">
            <button
              onClick={() => setActiveTab("upcoming")}
              className={`flex-1 py-4 font-bold text-center transition ${
                activeTab === "upcoming"
                  ? "text-primary border-b-2 border-primary"
                  : "text-dark/40 hover:text-dark/60"
              }`}
            >
              المواعيد القادمة ({upcoming.length})
            </button>
            <button
              onClick={() => setActiveTab("past")}
              className={`flex-1 py-4 font-bold text-center transition ${
                activeTab === "past"
                  ? "text-primary border-b-2 border-primary"
                  : "text-dark/40 hover:text-dark/60"
              }`}
            >
              السابقة ({past.length})
            </button>
          </div>

          {displayBookings.length === 0 ? (
            <div className="p-12 text-center text-dark/40">
              <Calendar className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="font-medium">ما عندك مواعيد {activeTab === "upcoming" ? "قادمة" : "سابقة"}</p>
              <Link
                href="/booking"
                className="inline-block mt-4 text-primary font-medium hover:underline"
              >
                احجز موعد جديد ←
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-dark/5">
              {displayBookings.map((booking) => {
                const status = statusConfig[booking.status];
                return (
                  <div
                    key={booking.id}
                    className="p-5 hover:bg-primary/[0.02] transition flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                        <Scissors className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-bold">{booking.service}</h3>
                        <p className="text-dark/50 text-sm flex items-center gap-2">
                          <MapPin className="w-3 h-3" />
                          {booking.salon}
                        </p>
                      </div>
                    </div>

                    <div className="hidden sm:flex items-center gap-6 text-sm text-dark/60">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {booking.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {booking.time}
                      </span>
                      <span className="font-bold text-primary">
                        {booking.price} ر.س
                      </span>
                    </div>

                    <div
                      className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${status.color}`}
                    >
                      <status.icon className="w-3 h-3" />
                      {status.label}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
