import { NextRequest, NextResponse } from "next/server";

type AgentRequest = {
  message: string;
  context?: {
    service?: string;
    salon?: string;
    date?: string;
    time?: string;
  };
};

const services: Record<string, { name: string; price: number; duration: string }> = {
  haircut: { name: "قص شعر", price: 50, duration: "30 دقيقة" },
  beard: { name: "تهذيب لحية", price: 30, duration: "20 دقيقة" },
  facial: { name: "عناية بالوجه", price: 80, duration: "45 دقيقة" },
  "hair-color": { name: "صبغة شعر", price: 150, duration: "60 دقيقة" },
  "hair-treatment": { name: "علاج شعر", price: 120, duration: "45 دقيقة" },
  "full-package": { name: "باكج كامل", price: 200, duration: "90 دقيقة" },
};

const salons = [
  { id: "elegance", name: "صالون الأناقة", rating: 4.8, location: "الرياض - حي الملقا" },
  { id: "prestige", name: "صالون بريستيج", rating: 4.9, location: "الرياض - حي النرجس" },
  { id: "royal", name: "صالون رويال", rating: 4.7, location: "الرياض - حي الياسمين" },
];

function generateAgentResponse(message: string): {
  reply: string;
  action?: string;
  data?: Record<string, string>;
} {
  const lower = message.toLowerCase();

  if (lower.includes("قص") || lower.includes("حلاق") || lower.includes("شعر")) {
    return {
      reply:
        "تمام! تبي قص شعر 💇‍♂️\nعندي مواعيد متاحة:\n\n📍 صالون الأناقة — السبت 4:00 عصراً\n📍 صالون بريستيج — الأحد 11:00 صباحاً\n\nأي موعد يناسبك؟",
      action: "suggest_service",
      data: { service: "haircut" },
    };
  }

  if (lower.includes("لحية") || lower.includes("ذقن")) {
    return {
      reply:
        "تبي تهذيب لحية 🧔\nعندي مواعيد:\n\n📍 صالون رويال — السبت 2:30 عصراً\n📍 صالون الأناقة — الأحد 10:00 صباحاً\n\nأي واحد تبي؟",
      action: "suggest_service",
      data: { service: "beard" },
    };
  }

  if (lower.includes("أكد") || lower.includes("اي") || lower.includes("تمام") || lower.includes("نعم")) {
    return {
      reply:
        "تم تأكيد حجزك بنجاح! ✅\n\nبرسل لك رسالة تأكيد على جوالك.\nيومك سعيد! 😊",
      action: "confirm_booking",
    };
  }

  if (lower.includes("سعر") || lower.includes("كم")) {
    const serviceList = Object.values(services)
      .map((s) => `• ${s.name}: ${s.price} ر.س (${s.duration})`)
      .join("\n");
    return {
      reply: `أسعار خدماتنا:\n\n${serviceList}\n\nوش تبي تحجز؟`,
      action: "show_prices",
    };
  }

  if (lower.includes("صالون") || lower.includes("وين")) {
    const salonList = salons
      .map((s) => `⭐ ${s.name} (${s.rating}) — ${s.location}`)
      .join("\n");
    return {
      reply: `صالوناتنا:\n\n${salonList}\n\nأي واحد تفضل؟`,
      action: "show_salons",
    };
  }

  return {
    reply:
      "أهلاً فيك! 😊\n\nأقدر أساعدك في:\n• حجز موعد جديد\n• عرض الأسعار\n• البحث عن صالون\n• تعديل أو إلغاء حجز\n\nقول لي وش تحتاج!",
    action: "greeting",
  };
}

export async function POST(request: NextRequest) {
  const body = (await request.json()) as AgentRequest;
  const { message } = body;

  if (!message) {
    return NextResponse.json({ error: "الرسالة مطلوبة" }, { status: 400 });
  }

  const response = generateAgentResponse(message);

  return NextResponse.json({
    reply: response.reply,
    action: response.action,
    data: response.data,
    timestamp: new Date().toISOString(),
  });
}
