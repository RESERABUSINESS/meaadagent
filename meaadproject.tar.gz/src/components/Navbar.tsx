"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, Calendar, Phone } from "lucide-react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const links = [
    { href: "#features", label: "المميزات" },
    { href: "#how-it-works", label: "كيف يعمل" },
    { href: "#pricing", label: "الأسعار" },
    { href: "#contact", label: "تواصل معنا" },
  ];

  return (
    <nav className="fixed top-0 right-0 left-0 z-50 glass-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold gradient-text">ميعاد</span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-dark/70 hover:text-primary transition-colors font-medium"
              >
                {link.label}
              </a>
            ))}
            <Link
              href="/booking"
              className="bg-primary text-white px-6 py-2.5 rounded-xl font-medium hover:bg-primary-dark transition-colors flex items-center gap-2"
            >
              <Phone className="w-4 h-4" />
              احجز الآن
            </Link>
          </div>

          <button
            className="md:hidden text-dark"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden glass-card border-t border-white/20">
          <div className="px-4 py-4 space-y-3">
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="block text-dark/70 hover:text-primary transition-colors font-medium py-2"
                onClick={() => setIsOpen(false)}
              >
                {link.label}
              </a>
            ))}
            <Link
              href="/booking"
              className="block bg-primary text-white px-6 py-2.5 rounded-xl font-medium text-center hover:bg-primary-dark transition-colors"
            >
              احجز الآن
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
