"use client";

import Link from "next/link";
import { Phone, Bot, Sparkles, ArrowLeft } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-bl from-primary/5 via-transparent to-secondary/5" />
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "3s" }} />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-slide-up">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4" />
              مدعوم بالذكاء الاصطناعي
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              احجز موعدك
              <br />
              <span className="gradient-text">بمكالمة واحدة</span>
              <br />
              من الإيجنت الذكي
            </h1>

            <p className="text-lg text-dark/60 mb-8 max-w-lg leading-relaxed">
              ميعاد هو نظام حجز المواعيد الذكي للصالونات. إيجنت AI يتصل بالصالون
              نيابة عنك، يحجز الموعد المناسب، ويأكد لك الحجز — كل شي أوتوماتيكي.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link
                href="/booking"
                className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-dark transition-all hover:scale-105 flex items-center gap-2 shadow-lg shadow-primary/30"
              >
                <Phone className="w-5 h-5" />
                جرّب الحجز الذكي
              </Link>
              <a
                href="#how-it-works"
                className="border-2 border-primary/20 text-primary px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary/5 transition-all flex items-center gap-2"
              >
                شاهد كيف يعمل
                <ArrowLeft className="w-5 h-5" />
              </a>
            </div>

            <div className="flex items-center gap-6 mt-10 text-sm text-dark/50">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                +500 صالون مشترك
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
                +10,000 حجز شهري
              </div>
            </div>
          </div>

          <div className="relative animate-slide-up" style={{ animationDelay: "0.3s" }}>
            <div className="relative glass-card rounded-3xl p-8 shadow-2xl">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-primary-light flex items-center justify-center animate-pulse-glow">
                  <Bot className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">إيجنت ميعاد</h3>
                  <p className="text-sm text-accent font-medium">متصل الآن...</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-primary/10 rounded-2xl rounded-tr-md p-4 max-w-[85%]">
                  <p className="text-sm">مرحباً! أنا إيجنت ميعاد. وش تبي تحجز اليوم؟</p>
                </div>
                <div className="bg-secondary/10 rounded-2xl rounded-tl-md p-4 max-w-[85%] mr-auto">
                  <p className="text-sm">أبي أحجز قص شعر عند صالون الأناقة يوم السبت</p>
                </div>
                <div className="bg-primary/10 rounded-2xl rounded-tr-md p-4 max-w-[85%]">
                  <p className="text-sm">
                    تمام! لقيت لك موعد يوم السبت الساعة 4:00 عصراً عند الحلاق أحمد. أأكد الحجز؟
                  </p>
                </div>
                <div className="bg-secondary/10 rounded-2xl rounded-tl-md p-4 max-w-[85%] mr-auto">
                  <p className="text-sm">إي أكّد 👍</p>
                </div>
                <div className="bg-accent/10 rounded-2xl p-4 border border-accent/20">
                  <div className="flex items-center gap-2 text-accent font-bold text-sm">
                    <Sparkles className="w-4 h-4" />
                    تم تأكيد الحجز بنجاح!
                  </div>
                  <p className="text-xs text-dark/50 mt-1">
                    السبت 4:00 عصراً — صالون الأناقة — قص شعر
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
