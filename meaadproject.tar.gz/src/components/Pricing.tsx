"use client";

import { Check, Star } from "lucide-react";

const plans = [
  {
    name: "مجاني",
    price: "0",
    period: "للأبد",
    description: "مثالي للتجربة",
    features: [
      "3 حجوزات شهرياً",
      "إيجنت شات فقط",
      "تنبيه واحد قبل الموعد",
      "دعم عبر البريد",
    ],
    cta: "ابدأ مجاناً",
    popular: false,
  },
  {
    name: "برو",
    price: "49",
    period: "شهرياً",
    description: "للاستخدام الشخصي",
    features: [
      "حجوزات غير محدودة",
      "إيجنت صوتي + شات",
      "تنبيهات ذكية متعددة",
      "إدارة المواعيد المتقدمة",
      "أولوية في الحجز",
      "دعم فوري",
    ],
    cta: "اشترك الآن",
    popular: true,
  },
  {
    name: "صالون",
    price: "199",
    period: "شهرياً",
    description: "للصالونات والأعمال",
    features: [
      "كل مميزات برو",
      "لوحة تحكم للصالون",
      "تحليلات وإحصائيات",
      "إدارة الموظفين",
      "API مخصص",
      "مدير حساب خاص",
    ],
    cta: "تواصل معنا",
    popular: false,
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            أسعار <span className="gradient-text">تناسب الجميع</span>
          </h2>
          <p className="text-dark/60 text-lg max-w-2xl mx-auto">
            اختر الباقة اللي تناسب احتياجك وابدأ اليوم
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-3xl p-8 transition-all duration-300 hover:-translate-y-2 ${
                plan.popular
                  ? "bg-gradient-to-br from-primary to-primary-dark text-white shadow-2xl shadow-primary/30 scale-105"
                  : "glass-card hover:shadow-xl"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-secondary text-dark px-4 py-1 rounded-full text-sm font-bold flex items-center gap-1">
                  <Star className="w-3 h-3" />
                  الأكثر طلباً
                </div>
              )}

              <h3 className="text-2xl font-bold mb-1">{plan.name}</h3>
              <p
                className={`text-sm mb-4 ${
                  plan.popular ? "text-white/70" : "text-dark/50"
                }`}
              >
                {plan.description}
              </p>

              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-bold">{plan.price}</span>
                <span
                  className={`text-sm ${
                    plan.popular ? "text-white/70" : "text-dark/50"
                  }`}
                >
                  ر.س / {plan.period}
                </span>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm">
                    <Check
                      className={`w-4 h-4 flex-shrink-0 ${
                        plan.popular ? "text-secondary" : "text-accent"
                      }`}
                    />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                className={`w-full py-3 rounded-xl font-bold transition-all hover:scale-105 ${
                  plan.popular
                    ? "bg-white text-primary hover:bg-white/90"
                    : "bg-primary text-white hover:bg-primary-dark"
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
