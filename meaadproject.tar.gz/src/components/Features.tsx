"use client";

import {
  Phone,
  Bot,
  Calendar,
  Clock,
  Shield,
  BarChart3,
  Bell,
  Smartphone,
  Globe,
} from "lucide-react";

const features = [
  {
    icon: Bot,
    title: "إيجنت ذكي يتصل نيابة عنك",
    description:
      "الإيجنت يتصل بالصالون، يتفاوض على الموعد، ويحجز لك — بدون ما تحتاج تسوي شي.",
    color: "from-primary to-primary-light",
  },
  {
    icon: Phone,
    title: "حجز بالمكالمة أو الشات",
    description:
      "اختر الطريقة اللي تناسبك: كلّم الإيجنت بالصوت أو اكتب له في الشات.",
    color: "from-secondary to-amber-400",
  },
  {
    icon: Calendar,
    title: "إدارة مواعيد متقدمة",
    description:
      "لوحة تحكم كاملة لإدارة مواعيدك، تعديلها، وإلغائها بسهولة.",
    color: "from-accent to-emerald-400",
  },
  {
    icon: Clock,
    title: "متاح ٢٤/٧",
    description:
      "الإيجنت يشتغل على مدار الساعة. احجز في أي وقت يناسبك حتى بعد منتصف الليل.",
    color: "from-blue-500 to-blue-400",
  },
  {
    icon: Bell,
    title: "تنبيهات ذكية",
    description:
      "يذكّرك بموعدك قبل ما يجي، ويرسل لك تأكيد فوري بعد كل حجز.",
    color: "from-pink-500 to-pink-400",
  },
  {
    icon: Shield,
    title: "خصوصية وأمان",
    description:
      "بياناتك محمية بتشفير متقدم. ما نشارك معلوماتك مع أي طرف ثالث.",
    color: "from-indigo-500 to-indigo-400",
  },
  {
    icon: BarChart3,
    title: "تحليلات للصالونات",
    description:
      "لوحة تحكم خاصة بالصالون تعرض إحصائيات الحجوزات وأوقات الذروة.",
    color: "from-orange-500 to-orange-400",
  },
  {
    icon: Smartphone,
    title: "تطبيق جوال",
    description:
      "تطبيق سهل وسريع على الجوال يخليك تتابع مواعيدك في أي مكان.",
    color: "from-teal-500 to-teal-400",
  },
  {
    icon: Globe,
    title: "دعم متعدد اللغات",
    description:
      "الإيجنت يتكلم عربي وإنجليزي، ويتعامل مع الصالونات بلغتهم.",
    color: "from-purple-500 to-purple-400",
  },
];

export default function Features() {
  return (
    <section id="features" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            كل اللي تحتاجه في{" "}
            <span className="gradient-text">مكان واحد</span>
          </h2>
          <p className="text-dark/60 text-lg max-w-2xl mx-auto">
            ميعاد يجمع لك كل مميزات الحجز الذكي مع تجربة سهلة وممتعة
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="glass-card rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
            >
              <div
                className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
              >
                <feature.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-dark/60 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
