"use client";

import { MessageSquare, Phone, CalendarCheck, Sparkles } from "lucide-react";

const steps = [
  {
    icon: MessageSquare,
    step: "١",
    title: "اختر الخدمة",
    description: "حدد الخدمة اللي تبيها والصالون المفضل عندك.",
  },
  {
    icon: Phone,
    step: "٢",
    title: "الإيجنت يتصل",
    description: "إيجنت ميعاد يتصل بالصالون ويتفاوض على أفضل موعد متاح.",
  },
  {
    icon: CalendarCheck,
    step: "٣",
    title: "تأكيد الحجز",
    description: "يأكد لك الحجز فوراً ويرسل لك التفاصيل كاملة.",
  },
  {
    icon: Sparkles,
    step: "٤",
    title: "استمتع بالخدمة",
    description: "روح موعدك وانت مرتاح — كل شي جاهز ومنظم.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-24 bg-gradient-to-b from-transparent to-primary/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            كيف يعمل <span className="gradient-text">ميعاد؟</span>
          </h2>
          <p className="text-dark/60 text-lg max-w-2xl mx-auto">
            أربع خطوات بسيطة وموعدك جاهز
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative text-center group">
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 -left-4 w-[calc(100%)] h-0.5 bg-gradient-to-l from-primary/30 to-primary/10" />
              )}
              <div className="relative z-10">
                <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-primary to-primary-light flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg shadow-primary/20">
                  <step.icon className="w-10 h-10 text-white" />
                </div>
                <div className="w-8 h-8 mx-auto -mt-6 mb-2 rounded-full bg-secondary text-white text-sm font-bold flex items-center justify-center">
                  {step.step}
                </div>
                <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                <p className="text-dark/60">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
