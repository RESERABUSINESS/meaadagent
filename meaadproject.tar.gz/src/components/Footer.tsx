import { Calendar } from "lucide-react";
import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-dark text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold">ميعاد</span>
            </Link>
            <p className="text-white/50 max-w-md leading-relaxed">
              نظام حجز المواعيد الذكي للصالونات. إيجنت AI يتصل ويحجز لك موعدك
              بدون عناء — مستقبل الحجز يبدأ من هنا.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-white/80">روابط سريعة</h4>
            <ul className="space-y-2">
              <li>
                <a href="#features" className="text-white/50 hover:text-white transition">
                  المميزات
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="text-white/50 hover:text-white transition">
                  كيف يعمل
                </a>
              </li>
              <li>
                <a href="#pricing" className="text-white/50 hover:text-white transition">
                  الأسعار
                </a>
              </li>
              <li>
                <a href="#contact" className="text-white/50 hover:text-white transition">
                  تواصل معنا
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-white/80">قانوني</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-white/50 hover:text-white transition">
                  سياسة الخصوصية
                </a>
              </li>
              <li>
                <a href="#" className="text-white/50 hover:text-white transition">
                  الشروط والأحكام
                </a>
              </li>
              <li>
                <a href="#" className="text-white/50 hover:text-white transition">
                  سياسة الاسترجاع
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 text-center text-white/40 text-sm">
          <p>© {new Date().getFullYear()} ميعاد. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
}
