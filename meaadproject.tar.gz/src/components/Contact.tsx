"use client";

import { useState } from "react";
import { Send, Mail, Phone, MapPin } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setFormData({ name: "", email: "", phone: "", message: "" });
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section id="contact" className="py-24 bg-gradient-to-b from-primary/5 to-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="gradient-text">تواصل</span> معنا
          </h2>
          <p className="text-dark/60 text-lg max-w-2xl mx-auto">
            عندك سؤال أو تبي تعرف أكثر؟ نحن هنا لمساعدتك
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          <div className="space-y-8">
            <div className="glass-card rounded-2xl p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Mail className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-bold mb-1">البريد الإلكتروني</h3>
                <p className="text-dark/60">info@meaad.ai</p>
              </div>
            </div>

            <div className="glass-card rounded-2xl p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-bold mb-1">الهاتف</h3>
                <p className="text-dark/60">+966 50 000 0000</p>
              </div>
            </div>

            <div className="glass-card rounded-2xl p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <h3 className="font-bold mb-1">الموقع</h3>
                <p className="text-dark/60">الرياض، المملكة العربية السعودية</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="glass-card rounded-2xl p-8 space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">الاسم</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                className="w-full px-4 py-3 rounded-xl border border-dark/10 bg-white/50 focus:outline-none focus:ring-2 focus:ring-primary/30 transition"
                placeholder="اسمك الكريم"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">البريد الإلكتروني</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                className="w-full px-4 py-3 rounded-xl border border-dark/10 bg-white/50 focus:outline-none focus:ring-2 focus:ring-primary/30 transition"
                placeholder="email@example.com"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">رقم الجوال</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
                className="w-full px-4 py-3 rounded-xl border border-dark/10 bg-white/50 focus:outline-none focus:ring-2 focus:ring-primary/30 transition"
                placeholder="05XXXXXXXX"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">الرسالة</label>
              <textarea
                value={formData.message}
                onChange={(e) =>
                  setFormData({ ...formData, message: e.target.value })
                }
                rows={4}
                className="w-full px-4 py-3 rounded-xl border border-dark/10 bg-white/50 focus:outline-none focus:ring-2 focus:ring-primary/30 transition resize-none"
                placeholder="كيف نقدر نساعدك؟"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-primary text-white py-3 rounded-xl font-bold hover:bg-primary-dark transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              {submitted ? "تم الإرسال بنجاح! ✓" : "أرسل الرسالة"}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
